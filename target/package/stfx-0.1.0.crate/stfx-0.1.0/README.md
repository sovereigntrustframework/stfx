# stfx

Top-level crate for the Sovereign Trust Framework (STFx).

Initial version depends only on `stfx-crypto` and re-exports it under `stfx::crypto`.

## Usage

```rust
use stfx::crypto; // re-export of stfx-crypto

fn main() {
    // Placeholder usage; see stfx-crypto docs for APIs.
}
```
