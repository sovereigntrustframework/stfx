# stfx-vid

Verifiable Identifiers (VID) primitives and utilities for STFx.

Initial release provides the crate scaffold; APIs will expand alongside `stfx-keys` and `stfx-crypto`.
